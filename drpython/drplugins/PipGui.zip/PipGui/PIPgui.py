import wx
import subprocess
import pkg_resources
import sys
import threading  # Додано для асинхронного виконання

class PipManager(wx.Frame):
    def __init__(self, *args, **kw):
        super(PipManager, self).__init__(*args, **kw)

        self.InitUI()

    def InitUI(self):
        panel = wx.Panel(self)
        vbox = wx.BoxSizer(wx.VERTICAL)

        # Заголовок та опис
        title = wx.StaticText(panel, label="Розпорядник пакетів PIP")
        font = wx.Font(18, wx.DEFAULT, wx.NORMAL, wx.BOLD)
        title.SetFont(font)
        vbox.Add(title, flag=wx.ALL | wx.ALIGN_CENTER, border=10)

        description = wx.StaticText(panel, label="Ця програма дозволяє керувати пакетами Python за допомогою pip.")
        vbox.Add(description, flag=wx.ALL | wx.ALIGN_CENTER, border=10)

        hbox = wx.BoxSizer(wx.HORIZONTAL)

        # Фрейм для списку пакетів
        self.packages_list = wx.ListBox(panel, style=wx.LB_SINGLE)
        hbox.Add(self.packages_list, proportion=1, flag=wx.EXPAND | wx.ALL, border=10)

        # Фрейм для кнопок
        buttons_panel = wx.Panel(panel)
        buttons_vbox = wx.BoxSizer(wx.VERTICAL)

        install_btn = wx.Button(buttons_panel, label='Встановити')
        install_btn.Bind(wx.EVT_BUTTON, self.OnInstall)
        buttons_vbox.Add(install_btn, flag=wx.EXPAND | wx.ALL, border=5)

        remove_btn = wx.Button(buttons_panel, label='Видалити')
        remove_btn.Bind(wx.EVT_BUTTON, self.OnRemove)
        buttons_vbox.Add(remove_btn, flag=wx.EXPAND | wx.ALL, border=5)

        info_btn = wx.Button(buttons_panel, label='Інформація')
        info_btn.Bind(wx.EVT_BUTTON, self.OnInfo)
        buttons_vbox.Add(info_btn, flag=wx.EXPAND | wx.ALL, border=5)

        buttons_panel.SetSizer(buttons_vbox)
        hbox.Add(buttons_panel, flag=wx.EXPAND | wx.ALL, border=10)

        vbox.Add(hbox, proportion=1, flag=wx.EXPAND)

        # Фрейм для сповіщень
        self.log = wx.TextCtrl(panel, style=wx.TE_MULTILINE | wx.TE_READONLY)
        vbox.Add(self.log, proportion=1, flag=wx.EXPAND | wx.ALL, border=10)

        panel.SetSizer(vbox)

        self.LoadPackages()

        self.SetSize((800, 600))
        self.SetTitle('Розпорядник пакетів PIP')
        self.Centre()

    def LoadPackages(self):
        self.packages_list.Clear()
        installed_packages = [pkg.key for pkg in pkg_resources.working_set]
        self.packages_list.AppendItems(installed_packages)

    def OnInstall(self, event):
        dlg = wx.TextEntryDialog(self, 'Введіть назву пакету для встановлення:', 'Встановити пакет')
        if dlg.ShowModal() == wx.ID_OK:
            package_name = dlg.GetValue()
            self.log.AppendText(f"Встановлення пакету {package_name}...\n")
            try:
                output = subprocess.check_output([sys.executable, '-m', 'pip', 'install', package_name], stderr=subprocess.STDOUT)
                self.log.AppendText(output.decode())
                self.LoadPackages()
            except subprocess.CalledProcessError as e:
                self.log.AppendText(f"Помилка: {e.output.decode()}\n")
        dlg.Destroy()

    def OnRemove(self, event):
        selection = self.packages_list.GetSelection()
        if selection != wx.NOT_FOUND:
            package_name = self.packages_list.GetString(selection)
            dlg = wx.MessageDialog(self, f"Ви впевнені, що хочете видалити пакет {package_name}?", 'Підтвердження видалення', wx.YES_NO | wx.ICON_QUESTION)
            if dlg.ShowModal() == wx.ID_YES:
                self.log.AppendText(f"Видалення пакету {package_name}...\n")
                try:
                    output = subprocess.check_output([sys.executable, '-m', 'pip', 'uninstall', '-y', package_name], stderr=subprocess.STDOUT)
                    self.log.AppendText(output.decode())
                    self.LoadPackages()
                except subprocess.CalledProcessError as e:
                    self.log.AppendText(f"Помилка: {e.output.decode()}\n")
            dlg.Destroy()

    def OnInfo(self, event):
        selection = self.packages_list.GetSelection()
        if selection != wx.NOT_FOUND:
            package_name = self.packages_list.GetString(selection)
            self.log.Clear()  # Очищення фрейму сповіщень
            self.log.AppendText(f"Отримання інформації про пакет {package_name}...\n")

            # Запуск команди у окремому потоці
            threading.Thread(target=self.GetPackageInfo, args=(package_name,), daemon=True).start()

    def GetPackageInfo(self, package_name):
        """Метод для отримання інформації про пакет у окремому потоці."""
        try:
            output = subprocess.check_output([sys.executable, '-m', 'pip', 'show', package_name], stderr=subprocess.STDOUT)
            wx.CallAfter(self.UpdateLog, output.decode())  # Оновлення GUI з головного потоку
        except subprocess.CalledProcessError as e:
            wx.CallAfter(self.UpdateLog, f"Помилка: {e.output.decode()}")

    def UpdateLog(self, message):
        """Оновлення текстового поля з головного потоку."""
        self.log.AppendText(message)
        self.log.SetInsertionPoint(0)  # Прокрутка до початку

    
def OnAbout(DrFrame):
    AboutString = """Pip GUI:

Version: 0.0.1

By G.Gromko

Released under the GPL."""
    DrFrame.ShowMessage(AboutString, "About")

def Plugin(DrFrame):
    def PipShow(event):
            frame = PipManager(None)
            frame.Show(True)
    
    ID_PIP_GUI = DrFrame.GetNewId()

    DrFrame.LoadPluginShortcuts('PIP GUI')
    DrFrame.optionsmenu.AppendSeparator()
    DrFrame.optionsmenu.Append(ID_PIP_GUI, "PIP GUI")

    DrFrame.Bind(wx.EVT_MENU, PipShow, id=ID_PIP_GUI)

    #DrFrame.AddPluginFunction("FullScreen", "Toggle FullScreen Mode", OnToggleFullScreen)
    
